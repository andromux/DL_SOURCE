# secrets.py
# Reemplaza 'TU_TOKEN_AQUI' con el token real de tu bot de Discord
TOKEN = 'TU_TOKEN_AQUI'