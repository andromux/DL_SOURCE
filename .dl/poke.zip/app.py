import discord
from discord.ext import commands
import requests
import secrets  # archivo secrets.py

# Configuración de permisos (intents)
intents = discord.Intents.default()
intents.message_content = True

# Creación del bot
bot = commands.Bot(command_prefix='$', intents=intents)

# El comando 'poke'
@bot.command()
async def poke(ctx, arg):
    try:
        pokemon = arg.split(" ", 1)[0].lower()
        result = requests.get("https://pokeapi.co/api/v2/pokemon/" + pokemon)
        if result.status_code == 404:
            await ctx.send("Pokemon No Encontrado")
        else:
            image_url = result.json()['sprites']['front_default']
            print(image_url)
            await ctx.send(image_url)
    except Exception as e:
        print("Error: ", e)

# Manejo de errores para el comando poke
@poke.error
async def error_type(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("Tienes que pasarme un Pokemon")

# Evento on_ready
@bot.event
async def on_ready():
    print(f"Estamos dentro! {bot.user}")

# Ejecución del bot
bot.run(secrets.TOKEN)